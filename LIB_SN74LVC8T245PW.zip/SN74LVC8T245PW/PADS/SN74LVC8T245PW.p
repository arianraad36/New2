*PADS-LIBRARY-PART-TYPES-V9*

SN74LVC8T245PW SOP65P640X120-24N I ANA 7 1 0 0 0
TIMESTAMP 2026.06.27.07.09.07
"Mouser Part Number" 595-SN74LVC8T245PW
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74LVC8T245PW?qs=dT9u2OTAaVWC4BAAt9onUQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74LVC8T245PW
"Description" Texas Instruments SN74LVC8T245PW, 1 Bus Transceiver, Bus Transceiver, 8-Bit Non-Inverting LVTTL, 24-Pin TSSOP
"Datasheet Link" https://www.ti.com/lit/gpn/sn74lvc8t245
"Geometry.Height" 1.2mm
GATE 1 24 0
SN74LVC8T245PW
1 0 U VCCA
2 0 U DIR
3 0 U A1
4 0 U A2
5 0 U A3
6 0 U A4
7 0 U A5
8 0 U A6
9 0 U A7
10 0 U A8
11 0 U GND_1
12 0 U GND_2
24 0 U VCCB_2
23 0 U VCCB_1
22 0 U \OE
21 0 U B1
20 0 U B2
19 0 U B3
18 0 U B4
17 0 U B5
16 0 U B6
15 0 U B7
14 0 U B8
13 0 U GND_3

*END*
*REMARK* SamacSys ECAD Model
4114627/748477/2.50/24/3/Integrated Circuit
