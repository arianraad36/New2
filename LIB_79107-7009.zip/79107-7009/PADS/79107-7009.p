*PADS-LIBRARY-PART-TYPES-V9*

79107-7009 791077009 I CON 7 1 0 0 0
TIMESTAMP 2026.06.23.08.46.19
"Mouser Part Number" 538-79107-7009
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/79107-7009?qs=IppS6Hsdlb4h1VTii4%252B%252Bgw%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 79107-7009
"Description" Headers & Wire Housings 20CIR VERT RECPT
"Datasheet Link" https://www.molex.com/pdm_docs/sd/791077009_sd.pdf
"Geometry.Height" 4.69mm
GATE 1 20 0
79107-7009
A1 0 U A1
A2 0 U A2
A3 0 U A3
A4 0 U A4
A5 0 U A5
A6 0 U A6
A7 0 U A7
A8 0 U A8
A9 0 U A9
A10 0 U A10
B1 0 U B1
B2 0 U B2
B3 0 U B3
B4 0 U B4
B5 0 U B5
B6 0 U B6
B7 0 U B7
B8 0 U B8
B9 0 U B9
B10 0 U B10

*END*
*REMARK* SamacSys ECAD Model
13508581/748477/2.50/20/3/Connector
