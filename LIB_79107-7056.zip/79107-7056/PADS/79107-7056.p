*PADS-LIBRARY-PART-TYPES-V9*

79107-7056 791077056 I CON 7 1 0 0 0
TIMESTAMP 2026.06.23.09.37.13
"Mouser Part Number" 538-79107-7056
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=538-79107-7056
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 79107-7056
"Description" Headers & Wire Housings MGrid VRec DR W/OPg W/OPgs .76AuLF 14Ckt
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/79107-7056.pdf
"Geometry.Height" 4.69mm
GATE 1 14 0
79107-7056
A1 0 U A1
A2 0 U A2
A3 0 U A3
A4 0 U A4
A5 0 U A5
A6 0 U A6
A7 0 U A7
B1 0 U B1
B2 0 U B2
B3 0 U B3
B4 0 U B4
B5 0 U B5
B6 0 U B6
B7 0 U B7

*END*
*REMARK* SamacSys ECAD Model
1955660/748477/2.50/14/4/Connector
